
<?php echo $this->load->view('includes/header');?>

<?php echo $this->load->view($main_content);?>

<?php echo $this->load->view('includes/footer');?>
