
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class Email extends MX_Controller 
{    

    function __construct() 
    {
        parent::__construct();
    }

    function index() 
    {
        
        $this->load->library('email',$config);
        $this->email->set_newline("\r\n");
        
        $this->email->from('ojt.amats2013@gmail.com','admin');
        $this->email->to('tyrone_060@live.com');
        $this->email->subject('tesssssssssting');
        $this->email->message('ayos');
        
        if($this->email->send())
        {
            echo 'your mail was sent';
        }
        else
        {
            show_error($this->email->print_debugger());
        }
    }
        
}