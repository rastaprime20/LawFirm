<div id=content class=span10>
    
    <!--Start of page bread crumb-->
    <div class=row-fluid>
        <div class=span12>
            <ul class=breadcrumb>
                <li>
                    <a href=<?php echo base_url(); ?>template/create>Templates</a> <span class=divider>/</span>
                </li>
            </ul>
        </div>
    </div>
    <!--End of page bread crumb-->
<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header well" data-original-title>
            <h2><i class="icon-list-alt"></i>Create Template</h2>
        </div>
        <div class="box-content">
            <div class="row-fluid">
                <label>Template Name <input type="text" style="width:40%"> </label>
                <div style="width:1000px;height:500px;margin-right:20%;margin-left:5%">
                    <object data="Doctemplates/Create-Template.docx" width="100%" height="400">
                    </object>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Save changes</button>
                <button type="reset" class="btn">Cancel</button>
            </div>
        </div>
    </div>
</div>