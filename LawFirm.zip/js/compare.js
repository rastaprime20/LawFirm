<script>
   function compare()
     {
         
        if (user_create==true)
           {
             x="Good day";
           }
       else
           {
             x="Good evening";
           } 
        
     }
</script>