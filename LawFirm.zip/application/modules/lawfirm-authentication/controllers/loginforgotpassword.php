
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Loginforgotpassword extends MX_Controller {

    public function __construct() 
    {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->library('form_validation');
        $this->load->database();
    }

    function index() {
        $data['main_content'] = 'resetpassword_view';
        $this->load->view('includes/logintemplate', $data);
    }

    public function forget() {
        
        session_start();
        
        if (isset($_SESSION['info'])) {
            $data['info'] = $_SESSION['info'];
        }
        if (isset($_SESSION['error'])) {
            $data['error'] = $_SESSION['error'];
        }


        $data['main_content'] = 'resetpassword_view';
        $this->load->view('includes/logintemplate', $data);
        
        
    }

    public function doforget() 
    {
        session_start();
        
        $this->load->helper('url');
        $email = $_POST['email'];
        $q = $this->db->query("select * from tbl_useraccount where userAccount_emailaddress ='" . $email . "'");
        if ($q->num_rows > 0) 
        {
            $r = $q->result();
            $user = $r[0];
            $this->resetpassword($user);
            $_SESSION['info'] = "Password has been reset and has been sent to email id: " . $email;
            redirect(base_url() . 'loginforgotpassword/forget', 'refresh');
        }
        $_SESSION['error'] = "The email id you entered not found on our database ";
        redirect(base_url() . 'loginforgotpassword/forget', 'refresh');
        
        session_destroy();
    }

    private function resetpassword($user) 
    {
        date_default_timezone_set('GMT');
        $this->load->helper('string');
        $setExpiry = '600'; //set expiry time
        $password = random_string('alnum', 16);
        $this->db->where('userAccount_id', $user->id);
        $this->db->update('tbl_useraccount', array('userAccount_defaultpassword' => SHA1($password)));

        $config = Array('protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'ojt.amats2013@gmail.com',
            'smtp_pass' => 'admin123!');
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");

        $email = $_POST['email'];
        $this->email->from('ojt.amats2013@gmail.com', 'admin');
        $this->email->to($email);
        $this->email->subject('Password reset');
        $this->email->message('You have requested the new password, Here is you new password:' . $password . $setExpiry);
        $this->email->send();
    }

}
