<?php echo $this->load->view('includes/logindesign');?>

<?php echo $this->load->view($main_content);?>